"""
TCI-LLM: Gradient-Free Language Modeling via Tensor Cross Interpolation.

This package provides a complete implementation of TCI-based language modeling,
demonstrating that gradients are optional for training on structured functions.

Main API:
    TCI_LLM.from_text(text) - Build model from text corpus
    TCI_LLM.from_file(path) - Build model from file
    model.generate(seed, n_tokens) - Generate text
    model.benchmark() - Measure throughput

Example:
    >>> from tci_llm import TCI_LLM
    >>> model = TCI_LLM.from_text("Hello world! Hello universe!")
    >>> model.generate(b"Hell", n_tokens=10)
    b'Hello worl'
"""

# Import QTT functions first (no dependencies)
from .qtt import (
    qtt_from_function_dense,
    qtt_eval_batch,
    qtt_eval_at_index,
    dense_to_qtt_cores,
)

# Import main class (depends on qtt)
from .tci_llm import TCI_LLM

__version__ = "1.0.0"
__all__ = [
    "TCI_LLM",
    "qtt_from_function_dense",
    "qtt_eval_batch",
    "qtt_eval_at_index",
    "dense_to_qtt_cores",
]
