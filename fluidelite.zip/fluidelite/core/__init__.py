"""
FluidElite Core Module
======================

Contains MPS, MPO, decompositions, and fast operations.
"""

from fluidelite.core.mps import MPS
from fluidelite.core.mpo import MPO
from fluidelite.core.decompositions import svd_truncated, qr_positive, rsvd_truncated, SafeSVD
from fluidelite.core.fast_ops import vectorized_mpo_apply, vectorized_mps_add
from fluidelite.core.cross import ProjectedActivation, gelu_mps

__all__ = [
    "MPS",
    "MPO",
    "svd_truncated",
    "qr_positive",
    "rsvd_truncated",
    "SafeSVD",
    "vectorized_mpo_apply",
    "vectorized_mps_add",
    "ProjectedActivation",
    "gelu_mps",
]
