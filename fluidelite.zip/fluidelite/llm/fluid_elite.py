"""
FluidElite: The Infinite Context QTT-LLM
========================================

Treats language modeling as fluid dynamics using tensor networks.

This is the OPTIMIZED version that uses:
- Vectorized MPO operations (EliteLinear)
- Projected activations (instead of full TT-Cross)
- Bitwise token embedding (zero parameters)

The system treats:
- MPS (Matrix Product State) = Hidden Context (the "fluid")
- MPO (Matrix Product Operator) = Weight Matrices (evolution operators)
- Truncation/SVD = Compression/Forgetting (maintains O(log N) memory)
- Token Processing = Time Evolution

Constitutional Compliance:
    - Article V.5.1: All public classes/methods documented
    - Article VII.7.2: Definition of Done = USER-OBSERVABLE BEHAVIOR works
"""

import torch
import torch.nn as nn
from fluidelite.core.mps import MPS
from fluidelite.core.mpo import MPO
from fluidelite.core.cross import ProjectedActivation
from fluidelite.core.fast_ops import vectorized_mpo_apply


class EliteLinear(nn.Module):
    """
    Vectorized MPO Linear Layer.
    
    Stores weights as a single stacked tensor instead of list of objects.
    This enables efficient GPU processing of entire MPS chains.
    
    The layer applies an MPO operator to an MPS, implementing a
    tensor network analog of a linear transformation.
    
    After application, truncates to max_rank to keep bonds bounded.
    
    Args:
        num_sites: Number of sites in the MPS chain (L)
        bond_dim: MPO bond dimension (D)
        phys_dim: Physical dimension at each site (d, default 2 for bits)
        max_rank: Maximum output bond dimension (defaults to bond_dim)
        
    Attributes:
        cores: Learnable parameter tensor (L, D, d, d, D)
        
    Example:
        >>> layer = EliteLinear(num_sites=12, bond_dim=32)
        >>> mps_out = layer(mps_in)
    """
    def __init__(self, num_sites: int, bond_dim: int, phys_dim: int = 2, max_rank: int = None):
        super().__init__()
        self.L = num_sites
        self.D = bond_dim
        self.d = phys_dim
        self.max_rank = max_rank if max_rank is not None else bond_dim
        
        # Parameter: Single Tensor (L, D, d, d, D)
        # Small random initialization for stability
        self.cores = nn.Parameter(
            torch.randn(num_sites, bond_dim, phys_dim, phys_dim, bond_dim, 
                       dtype=torch.float64) * 0.02
        )
        
        # Identity initialization bias for stability
        # This makes the initial layer close to identity transformation
        with torch.no_grad():
            for i in range(min(bond_dim, phys_dim)):
                # Add identity on diagonal elements
                if i < phys_dim:
                    self.cores[:, i, :, :, i] += torch.eye(phys_dim, dtype=torch.float64)

    def forward(self, mps: MPS) -> MPS:
        """
        Apply MPO layer to MPS with truncation.
        
        Args:
            mps: Input MPS state
            
        Returns:
            Output MPS with MPO applied
        """
        # Convert MPS tensors to stacked form if needed
        if isinstance(mps.tensors, list):
            # Pad to uniform shape for vectorized operation
            max_chi = max(max(t.shape[0], t.shape[2]) for t in mps.tensors)
            
            # Simple case: just stack if already uniform
            try:
                mps_stack = torch.stack(mps.tensors)
            except RuntimeError:
                # Non-uniform: need to use loop-based approach
                return self._forward_loop(mps)
        else:
            mps_stack = mps.tensors

        # Use vectorized operation
        out_stack = vectorized_mpo_apply(mps_stack, self.cores)
        
        result = MPS([t for t in out_stack])
        
        # Always truncate/fix to ensure proper MPS structure
        # (vectorized ops produce uniform shapes which may violate open boundaries)
        result.canonicalize_to_(site=self.L // 2)
        result.truncate_(chi_max=self.max_rank)
            
        return result
    
    def _forward_loop(self, mps: MPS) -> MPS:
        """
        Fallback loop-based forward for non-uniform MPS.
        
        Args:
            mps: Input MPS with non-uniform bond dimensions
            
        Returns:
            Output MPS (truncated to max_rank)
        """
        new_tensors = []
        
        for i in range(self.L):
            A = mps.tensors[i]  # (chi_l, d, chi_r)
            W = self.cores[i]  # (D, d_out, d_in, D)
            
            # Contract: W_abcd, A_ecf -> B_eabfd (contract on c=d_in)
            B = torch.einsum("abcd,ecf->eabfd", W, A)
            
            # Reshape to (chi_l * D, d_out, chi_r * D)
            chi_l, D_l = A.shape[0], W.shape[0]
            d_out = W.shape[1]
            chi_r, D_r = A.shape[2], W.shape[3]
            
            B = B.reshape(chi_l * D_l, d_out, chi_r * D_r)
            new_tensors.append(B)
        
        result = MPS(new_tensors)
        
        # Truncate to max_rank
        if result.chi > self.max_rank:
            result.canonicalize_to_(site=self.L // 2)
            result.truncate_(chi_max=self.max_rank)
            
        return result


class FluidElite(nn.Module):
    """
    The Optimized Fluid Engine for Infinite-Context Language Modeling.
    
    Uses Vectorized Kernels + Projected GELU + Riemannian Stability.
    
    Architecture:
        1. Token → Bitwise MPS embedding (zero parameters)
        2. W_hidden: MPO layer for hidden state evolution
        3. W_input: MPO layer for input injection
        4. Direct sum: Combine hidden and input contributions
        5. Projected GELU activation
        6. Linear head for vocabulary prediction
        
    The key insight is that context is stored as an MPS that evolves
    over time, similar to fluid dynamics. The bond dimension controls
    memory capacity, while truncation implements "forgetting".
    
    Args:
        num_sites: Number of sites (L). Determines token space: 2^L distinct tokens
        rank: Bond dimension (χ). Controls memory capacity
        vocab_size: Output vocabulary size for prediction head
        
    Example:
        >>> model = FluidElite(num_sites=12, rank=32, vocab_size=100)
        >>> ctx = MPS.random(12, d=2, chi=1)  # Initial empty context
        >>> for token in sequence:
        ...     ctx = model.step(ctx, token)
        >>> logits = model.predict(ctx)
    """
    def __init__(self, num_sites: int = 12, rank: int = 32, vocab_size: int = 100):
        super().__init__()
        self.L = num_sites
        self.rank = rank
        self.vocab_size = vocab_size
        
        # Vectorized MPO Layers
        self.W_hidden = EliteLinear(num_sites, rank, phys_dim=2)
        self.W_input = EliteLinear(num_sites, rank, phys_dim=2)
        
        # Activation
        self.act = ProjectedActivation(torch.nn.functional.gelu, max_rank=rank)
        
        # Readout head: maps middle bond features to vocabulary logits
        self.head = nn.Linear(rank, vocab_size, dtype=torch.float64)
        
        # Embedding buffers for bitwise encoding
        # |0⟩ = [1, 0], |1⟩ = [0, 1]
        self.register_buffer('zero', torch.tensor([1., 0.], dtype=torch.float64).view(1, 2, 1))
        self.register_buffer('one', torch.tensor([0., 1.], dtype=torch.float64).view(1, 2, 1))

    def embed(self, token_id: int) -> MPS:
        """
        Maps token_id (int) → MPS product state using bitwise decomposition.
        
        This is a zero-parameter embedding that encodes the token ID
        in binary form. Token 451 → binary bits → MPS of |0⟩/|1⟩ states.
        
        Args:
            token_id: Integer token ID (0 to 2^L - 1)
            
        Returns:
            MPS product state representing the token
            
        Example:
            >>> model = FluidElite(num_sites=8, rank=32, vocab_size=256)
            >>> mps = model.embed(65)  # ASCII 'A' = 65 = 0b01000001
        """
        # Extract bits from token_id (LSB first, then reverse for consistency)
        bits = [(token_id >> i) & 1 for i in range(self.L)]
        
        # Create product state MPS from bits
        tensors = torch.stack([self.one if b else self.zero for b in reversed(bits)])
        
        return MPS(list(tensors))

    def step(self, context_mps: MPS, token_id: int) -> MPS:
        """
        One step of the fluid evolution.
        
        Implements: h_{t+1} = GELU(W_hidden @ h_t + W_input @ embed(token))
        
        This is the core "time evolution" step that updates the hidden
        state (context) based on the new token.
        
        Args:
            context_mps: Current hidden state MPS
            token_id: New token to process
            
        Returns:
            Updated hidden state MPS
            
        Example:
            >>> ctx = MPS.random(12, d=2, chi=1)
            >>> for token in [42, 13, 7]:
            ...     ctx = model.step(ctx, token)
        """
        # Embed token as MPS
        token_mps = self.embed(token_id)
        
        # Linear Ops (through MPO layers)
        h_term = self.W_hidden(context_mps)
        x_term = self.W_input(token_mps)
        
        # Add via Direct Sum (block diagonal)
        # For MPS sum: |ψ⟩ + |φ⟩, the tensors are block diagonal
        # except at boundaries which need special treatment
        new_cores = []
        for i, (c1, c2) in enumerate(zip(h_term.tensors, x_term.tensors)):
            l1, d, r1 = c1.shape
            l2, _, r2 = c2.shape
            
            if i == 0:
                # First site: left bond is 1 for both, concat along right bond
                # Shape: (1, d, r1+r2)
                new_c = torch.cat([c1, c2], dim=2)
            elif i == self.L - 1:
                # Last site: right bond is 1 for both, concat along left bond
                # Shape: (l1+l2, d, 1)
                new_c = torch.cat([c1, c2], dim=0)
            else:
                # Interior sites: block diagonal
                # Shape: (l1+l2, d, r1+r2)
                new_c = torch.zeros(l1 + l2, d, r1 + r2, device=c1.device, dtype=c1.dtype)
                new_c[:l1, :, :r1] = c1
                new_c[l1:, :, r1:] = c2
            new_cores.append(new_c)
        
        pre_act_state = MPS(new_cores)
        
        # Activation (includes truncation back to target rank)
        post_act_state = self.act(pre_act_state)
        
        return post_act_state

    def predict(self, mps: MPS) -> torch.Tensor:
        """
        Extract logits from the MPS hidden state.
        
        Uses the middle bond of the MPS as a feature vector,
        then applies linear head to get vocabulary logits.
        
        Args:
            mps: Current hidden state MPS
            
        Returns:
            Logits tensor of shape (vocab_size,)
            
        Example:
            >>> logits = model.predict(ctx)
            >>> next_token = logits.argmax().item()
        """
        # Get tensor at middle site
        mid_idx = self.L // 2
        mid = mps.tensors[mid_idx]
        
        # Average over physical and left bond dimensions to get right bond vector
        vec = mid.mean(dim=(0, 1))  # Shape: (chi_right,)
        
        # Pad or truncate to match head input dimension
        if vec.shape[0] < self.rank:
            vec = torch.cat([
                vec, 
                torch.zeros(self.rank - vec.shape[0], device=vec.device, dtype=vec.dtype)
            ])
        elif vec.shape[0] > self.rank:
            vec = vec[:self.rank]
            
        return self.head(vec)
    
    def forward(self, token_ids: list[int], initial_context: MPS | None = None) -> torch.Tensor:
        """
        Process a sequence of tokens and return final logits.
        
        Args:
            token_ids: List of token IDs to process
            initial_context: Starting MPS state (default: random chi=1)
            
        Returns:
            Logits for next token prediction
            
        Example:
            >>> logits = model([1, 2, 3, 4, 5])
        """
        if initial_context is None:
            initial_context = MPS.random(
                self.L, d=2, chi=1, 
                device=self.head.weight.device,
                dtype=torch.float64
            )
            
        ctx = initial_context
        for token_id in token_ids:
            ctx = self.step(ctx, token_id)
            
        return self.predict(ctx)
